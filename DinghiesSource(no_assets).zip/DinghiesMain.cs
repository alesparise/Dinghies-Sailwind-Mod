﻿using System;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;
using Object = UnityEngine.Object;
//poorly written by pr0skynesis (discord username)

namespace Dinghies
{
    [BepInPlugin(pluginGuid, pluginName, pluginVersion)]
    public class DinghiesMain : BaseUnityPlugin
    {
        // Necessary plugin info
        public const string pluginGuid = "pr0skynesis.dinghies";
        public const string pluginName = "Dinghies";
        public const string pluginVersion = "1.0.0";

        //config file info
        public static ConfigEntry<bool> nothingConfig;

        public void Awake()
        {
            //patching info
            Harmony harmony = new Harmony(pluginGuid);
            MethodInfo original = AccessTools.Method(typeof(FloatingOriginManager), "Start");
            MethodInfo patch = AccessTools.Method(typeof(DinghiesPatches), "StartPatch");
            harmony.Patch(original, new HarmonyMethod(patch));
            //patch to attach initial sails
            MethodInfo original2 = AccessTools.Method(typeof(Mast), "Start");
            MethodInfo patch2 = AccessTools.Method(typeof(DinghiesPatches), "SailSetupPatch");
            harmony.Patch(original2, new HarmonyMethod(patch2));

            //Create config file in BepInEx\config\
            nothingConfig = Config.Bind("A) General Settings", "nothing", true, "This setting does nothing. Default is True, set to false to disable.");

        }
    }
    public class DinghiesPatches
    {
        // variables 
        public static AssetBundle bundle;
        public static string bundlePath;
        public static GameObject cutter;
        public static GameObject cutterEmbark;
        // PATCHES
        [HarmonyPrefix]
        public static void StartPatch(FloatingOriginManager __instance)
        {
            SetupThings();
            Transform shiftingWorld = __instance.transform;
            cutter = Object.Instantiate(cutter, shiftingWorld);
            //SET UP WALK COL
            cutterEmbark = cutter.transform.Find("WALK cutter").gameObject;
            cutterEmbark.transform.parent = GameObject.Find("walk cols").transform;
            //RUDDER THINGS
            cutter.transform.Find("cutterModel").Find("rudder").Find("rudder_tiller_cutter").gameObject.AddComponent<TillerRudder>();
            //SET INITIAL POSITION
            SetRotation(cutter, -89.8f);
            SetMooring(cutter, shiftingWorld);
        }
        [HarmonyPrefix]
        public static void SailSetupPatch(Mast __instance)
        {   // set the inital sail to attach them
            if (__instance.transform.parent.parent.name == "cutterModel")
            {   //if this is a mast on the cutter
                GameObject[] sails = PrefabsDirectory.instance.sails;
                GameObject mainSail = sails[45];
                GameObject mizzenSail = sails[3];
                if (__instance.name == "mizzen_mast")
                {
                    __instance.startSailPrefab = mizzenSail;
                }
                if (__instance.name == "main_mast")
                {
                    __instance.startSailPrefab = mainSail;
                }
            }
        }
        // HELPER METHODS
        public static void SetupThings()
        {   // loads the boat prefab
            bundlePath = Paths.PluginPath + "\\Dinghies\\dinghies";
            bundle = AssetBundle.LoadFromFile(bundlePath);
            if (bundle == null)
            {   // Maybe the user downloaded from thunderstore...
                bundlePath = Paths.PluginPath + $"\\Pr0SkyNesis-Dinghies-{DinghiesMain.pluginVersion}" + "\\dinghies";
                bundle = AssetBundle.LoadFromFile(bundlePath);
                if (bundle == null)
                {
                    Debug.LogError("Dinghies: Bundle not loaded! Did you place it in the correct folder?");
                }
            }
            string cutterPath = "Assets/Dinghies/BOAT Cutter (130).prefab";
            cutter = bundle.LoadAsset<GameObject>(cutterPath);

            //Set the region
            cutter.GetComponent<PurchasableBoat>().region = GameObject.Find("Region Medi").GetComponent<Region>();

            //Fix materials
            MatLib.RegisterMaterials();
            cutter.transform.Find("WaterFoam").GetComponent<MeshRenderer>().material = MatLib.foam;
            cutter.transform.Find("WaterObjectInteractionSphereBack").GetComponent<MeshRenderer>().material = MatLib.objectInteraction;
            cutter.transform.Find("WaterObjectInteractionSphereFront").GetComponent<MeshRenderer>().material = MatLib.objectInteraction;
            cutter.transform.Find("cutterModel").Find("mask").GetComponent<MeshRenderer>().material = MatLib.convexHull;
            cutter.transform.Find("cutterModel").Find("damage_water").GetComponent<MeshRenderer>().material = MatLib.water4;
            cutter.transform.Find("cutterModel").Find("mask_splash").GetComponent<MeshRenderer>().material = MatLib.mask;
            cutter.transform.Find("overflow particles").GetComponent<Renderer>().material = MatLib.overflow;
            cutter.transform.Find("overflow particles (1)").GetComponent<Renderer>().material = MatLib.overflow;

            //Easter egg
            cutter.transform.Find("cutterModel").Find("easter_egg").gameObject.SetActive(false);
            if (DinghiesMain.nothingConfig.Value)
            {
                EasterEgg(cutter.transform.Find("cutterModel").Find("easter_egg").gameObject);
            }
        }
        public static void SetRotation(GameObject boat, float yRot)
        {   //set the initial rotation of the boat
            boat.transform.eulerAngles = new Vector3 (0f, yRot, 0f);
        }
        public static void SetMooring(GameObject boat, Transform shiftingWorld)
        {   //attach the initial mooring lines to the correct cleats
            Transform fort = shiftingWorld.Find("island 15 M (Fort)");
            cutter.GetComponent<BoatMooringRopes>().mooringFront = fort.Find("dock_mooring M").transform;
            cutter.GetComponent<BoatMooringRopes>().mooringBack = fort.Find("dock_mooring M (8)").transform;
        }
        public static void EasterEgg(GameObject easterEgg)
        {   //does absolutely nothing on a specific or date range

            DateTime today = DateTime.Now;
            int month = today.Month;
            int day = today.Day;
            if ((month == 12 && day >= 8) || (month == 1 && day <= 6))
            {
                easterEgg.SetActive(true);
            }
        }
    }
    //ADDITIONAL SCRIPTS
    public class TillerRudder : GoPointerButton
    {   //Enables the tiller controlling the rudder
        
        private Rudder rudder;
        private HingeJoint hingeJoint;
        private bool locked;
        public float input;
        private float rotationAngleLimit;
        private void Awake()
        {
            rudder = transform.parent.GetComponent<Rudder>();
            hingeJoint = rudder.GetComponent<HingeJoint>();
            input = 0f;
            rotationAngleLimit = hingeJoint.limits.max;
        }
        public override void OnActivate(GoPointer activatingPointer)
        {
            if (Settings.steeringWithMouse && activatingPointer.type == GoPointer.PointerType.crosshairMouse)
            {
                MouseLook.ToggleMouseLook(newState: false);
            }

            if (!Settings.steeringWithMouse && activatingPointer.type == GoPointer.PointerType.crosshairMouse)
            {
                StickyClick(activatingPointer);
            }

            if (locked)
            {
                Unlock();
            }
        }
        public override void OnUnactivate(GoPointer activatingPointer)
        {
            if (Settings.steeringWithMouse && activatingPointer.type == GoPointer.PointerType.crosshairMouse)
            {
                MouseLook.ToggleMouseLook(newState: true);
            }
            if (!locked)
            {
                //Debug.LogWarning("Dinghies: Tiller unactivated");
                //input = 0f; //reset the input when uncklicking
                //this does not work properly, OnUnactivate is only called when clicking again on the button, not when clicking away from it!
            }
        }
        private void ToggleLock()
        {
            if (!locked)
            {
                Lock();
            }
            else
            {
                Unlock();
            }
        }
        private void Lock()
        {
            if ((bool)stickyClickedBy)
            {
                UnStickyClick();
            }

            locked = true;
            Juicebox.juice.PlaySoundAt("lock unlock", base.transform.position, 0f, 0.66f, 0.88f);
            //Debug.Log("locking wheel");
        }
        private void Unlock()
        {
            locked = false;
            Juicebox.juice.PlaySoundAt("lock unlock", base.transform.position, 0f, 0.66f, 1f);
            //Debug.Log("unlocking wheel");
        }
        public override void ExtraLateUpdate()
        {   // controls the tiller and the rudder connected to it
            // NOTE: this needs some kind of feedback! The input value should be affected by the rudder angle!
            
            if((bool)stickyClickedBy || isClicked)
            {   //when it's clicked we control it with the A and D keys
                if (stickyClickedBy.AltButtonDown())
                {
                    ToggleLock();
                }
                if (!locked)
                {
                    input += stickyClickedBy.movement.GetKeyboardDelta().x * 0.02f;
                }
                ApplyRotationLimit();
                RotateRudderAlt();
            }
            else if (locked)
            {   //keep applying the rotation if it's locked. Also the input does not get set to 0 if it's locked
                ApplyRotationLimit();
                RotateRudderAlt();
            }
            else
            {   //not clicked and not locked, make it self center (need to check if it works under sail!)
                //UnStickyClick();
                input = 0f;
            }
            //Debug.Log($"input: {Math.Round(input, 2)} angle: {Math.Round(rudder.currentAngle, 2)}");
        }
        private void RotateRudder()
        {   //old, taken from GPButtonSteeringWheel
            //The custom made one seems better
            float num = input / rotationAngleLimit;
            JointSpring spring = hingeJoint.spring;
            spring.targetPosition = hingeJoint.limits.max * num;
            hingeJoint.spring = spring;
        }
        private void ApplyRotationLimit()
        {   //limits the input value betwee the min and max rotation limit
            if (input > rotationAngleLimit)
            {
                input = rotationAngleLimit;
            }

            if (input < 0f - rotationAngleLimit)
            {
                input = 0f - rotationAngleLimit;
            }
        }
        private void RotateRudderAlt()
        {   //alternative way to operate the rudder
            //rudder.currentAngle = input; //DEBUG: It worked with this, add it back if it does not work anymore!
            JointSpring spring = hingeJoint.spring;
            spring.targetPosition = input;
            hingeJoint.spring = spring;
        }
    }
    public class MatLib
    {   // manages a material library to easily access and assign materials that are not correctly decompiled (e.g Crest materials)
        public static Material convexHull;
        public static Material foam;
        public static Material objectInteraction;
        public static Material water4;
        public static Material mask;
        public static Material overflow;

        public static void RegisterMaterials()
        {   //save the materials from the cog to the variables so that I can then easily assign them to the dinghy's gameobjects
            GameObject cog = GameObject.Find("BOAT medi small (40)");
            convexHull = cog.transform.Find("medi small").Find("mask").GetComponent<MeshRenderer>().sharedMaterial;
            foam = cog.transform.Find("WaterFoam").GetComponent<MeshRenderer>().sharedMaterial;
            objectInteraction = cog.transform.Find("WaterObjectInteractionSphereBack").GetComponent<MeshRenderer>().sharedMaterial;
            water4 = cog.transform.Find("medi small").Find("damage_water").GetComponent<MeshRenderer>().sharedMaterial;
            mask = cog.transform.Find("medi small").Find("mask_splash").GetComponent<MeshRenderer>().sharedMaterial;
            overflow = cog.transform.Find("overflow particles").GetComponent<Renderer>().sharedMaterial;

            /*if ( convexHull != null && foam != null && objectInteraction != null && water4 != null && mask != null)
            {
                Debug.LogWarning("Dinghies: Material registered correctly");
            }*/
        }
    }
}
